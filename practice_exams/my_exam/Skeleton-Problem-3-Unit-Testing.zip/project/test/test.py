import unittest
from project.star_system import StarSystem

